#!/sbin/sh
echo gzip > /tmp/split_img/boot.img-ramdiskcomp;
