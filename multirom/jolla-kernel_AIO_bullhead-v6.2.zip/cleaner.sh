#!/sbin/sh

rm -rf /system/app/jolla-kernel_Updater
rm -rf /data/app/com.jollakernelupdater*
rm -rf /data/dalvik-cache/arm/*jolla-kernel_Updater*
rm -rf /data/dalvik-cache/arm/*com.jollakernelupdater*
rm -rf /data/dalvik-cache/arm64/*jolla-kernel_Updater*
rm -rf /data/dalvik-cache/arm64/*com.jollakernelupdater*
rm -rf /data/dalvik-cache/profiles/com.jollakernelupdater
rm -rf /system/app/A2DPChecker
rm -rf /data/app/com.jollaman999.bluetootha2dp*
rm -rf /data/dalvik-cache/arm/*A2DPChecker*
rm -rf /data/dalvik-cache/arm/*com.jollaman999.bluetootha2dp*
rm -rf /data/dalvik-cache/arm64/*A2DPChecker*
rm -rf /data/dalvik-cache/arm64/*com.jollaman999.bluetootha2dp*
rm -rf /data/dalvik-cache/profiles/com.jollaman999.bluetootha2dp
rm -rf /system/app/USB-Keyboard
rm -rf /data/app/remote.hid.keyboard.client*
rm -rf /data/dalvik-cache/arm/*USB-Keyboard*
rm -rf /data/dalvik-cache/arm/*remote.hid.keyboard.client*
rm -rf /data/dalvik-cache/arm64/*USB-Keyboard*
rm -rf /data/dalvik-cache/arm64/*remote.hid.keyboard.client*
rm -rf /data/dalvik-cache/profiles/remote.hid.keyboard.client
